from cgitb import reset
from pygame import rect
from ctypes.wintypes import ATOM
from timeit import repeat
from turtle import clear, delay
import pygame


import sys 

from pygame import Vector2

from pygame import mixer              

import random

#from symbol import atom_exp

# clock and timing
clock = pygame.time.Clock()

R = 0
I = 0 
atom = 0
playerX = 380
PlayerY = 40
pixel = 64

class Cloud(pygame.sprite.Sprite):

    pygame.init()
screen_height = 800
screen_width = 600
windowSize = [screen_height, screen_width]
screen = pygame.display.set_mode(windowSize)




#screen colours
lightblue = (121, 172, 252)
green = (53, 145, 36)
brown = (115, 86, 53)

#caption+icon
pygame.display.set_caption("Carbon Catcher")
icon = pygame.image.load('cloud (3).png')
pygame.display.set_icon(icon)

#player
player = pygame.image.load('BNK.png').convert_alpha()
playerX = 380
PlayerY = 40
playerX_change = 0
playerImg = pygame.transform.scale(player,(200,120))
player_rect = pygame.Surface.get_rect(player)
#rectplayer = pygame.rect(playerX, PlayerY,100,100)

def player(x,y):
    screen.blit(playerImg, (x,y))
background_surface = pygame.Surface((screen_width, screen_height))


#bg = pygame.image.load ("bg.png") #INSIDE OF THE GAME LOOP gameDisplay.blit (bg, (0, 0)) #REST OF ITEMS ARE BLIT'D TO SCREEN

class atom (pygame.sprite.Sprite):

    pygame.init()
    
    co2img = pygame.image.load ("co2.png").convert_alpha()
    co2X = random.randrange(50, 700)
    co2Y = 750
    co2img = pygame.transform.scale(co2img,(100,100))
    co2_rect2 = pygame.Surface.get_rect(co2img)
    atom_rect = pygame.Rect(co2X,co2Y,70,70)
    
     #The rect for collision detection.
    #if co2Y and co2X == atom_rect:
    #    co2X = random.randrange(50, 750)
    #    co2Y = 300


    # [e.g. a function to calculate new position]
    # [and a function to check if it hits the side]


#Background
MpngImg = pygame.image.load ("Mountain.png") 
MpgnX = screen_height
MpgnY = screen_width
MpgnX_change = 0
MpngImg = pygame.transform.scale(MpngImg,(MpgnX, MpgnY))


#grass
grassImg = pygame.image.load("grassv2.png")
grassX = 0
grassY = 480
grassX_change = 0
grassImg = pygame.transform.scale(grassImg,(800,120))

#City
cityImg = pygame.image.load("boom.png")
cityX = 270
cityY = 310
cityX_change = 0
cityImg = pygame.transform.scale(cityImg,(340,220))

#hp_outline
# rectImg = pygame.image.load ("square.png") 
# rectX = 0
# rectY = 200
# rectX_change = 0
# rectImg = pygame.transform.scale(rectImg,(100,500))

#atoms

co2img = pygame.image.load ("co2.png")
co2X = random.randrange(50, 750)
co2Y = 700
co2img = pygame.transform.scale(co2img,(100,100))


def co2 (x , y):
    screen.blit (co2img, (x ,y))

def Background (x , y):
    screen.blit (MpngImg, (x , y))

# def rectange (x , y):
#     screen.blit(rectImg, (x , y))
def grass (x , y):
    screen.blit(grassImg, (x , y))

def city (x , y):
    screen.blit(cityImg, (x , y))



font1 = pygame.font.Font('Font.ttf', 20)
font = pygame.font.Font('Font.ttf', 40)
font2 = pygame.font.Font('Font.ttf', 65)
#define colours
TEXT_COL = (255,255,255)
def draw_text(text, font, text_col, x, y):
    img = font.render(text,True,text_col)
    screen.blit(img, (x,y))



running = True
while running:
    screen.fill((lightblue))
    screen.blit (MpngImg, (0 , 0))
    draw_text("[space]=menue", font1, TEXT_COL, 20,270)
    
    #print (range(playerX-20, playerX+20))
    I = 1
    #print (playerX)
    if R == 1:
       co2X = random.randrange(50, 750)
       co2Y = 700
       R = 0
    if  I == 1:
        co2Y -= 2
    if co2Y == -50:
            R = 1

            
    if co2Y in range(30, 60) and co2X in range(playerX-10, playerX+200):
        R = 1
    #HELP?!!!
    if co2Y <= -100:
        R = 1

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                I=0
                pygame.quit()
        if event.type == pygame.QUIT:
                I=0
                pygame.quit()
                sys.exit()
                
                
                

        if co2Y == atom.atom_rect and co2X == atom.atom_rect:
            R = 1
        #if left / right button is pressed
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -5
            if event.key == pygame.K_RIGHT:
                playerX_change = 5
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0
    Background(MpgnX, MpgnY)
    city(cityX, cityY)
    grass(grassX, grassY)
    co2(co2X,co2Y)
    # rectange(rectX,rectY)
    # 5 = 5 + -0.1 -> 5 = 5 - 0.1
    #5 = 5 + 0.1

    #borders
    playerX += playerX_change

    if playerX <= 50:
        playerX = 50
    elif playerX >= 600:
        playerX = 600


    player(playerX,PlayerY)
    pygame.display.update()
pygame.quit()